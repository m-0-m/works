
	var aItemTitle = document.getElementsByClassName('item-list-title');
	var aItemList = document.getElementsByClassName('item-list');
	var timeout;
	
	for(let i = 0;i < aItemTitle.length;i++){
		aItemTitle[i].onclick = function(){
			for( let x = 0;x < aItemTitle.length;x++){
				if( i !== x ) {
					clearTimeout(timeout);
					aItemTitle[x].className = 'item-list-title';
					aItemList[x].className = 'item-list animation-out';
					aItemList[x].style.height = 30 + 'px';
				}
			}
			if(aItemTitle[i].className == 'item-list-title'){
				let numHeight = aItemList[i].childNodes.length;
				let listHeight = (numHeight - 3) * 13 + 50;
				aItemList[i].style.height = listHeight + 'px';
				timeout = setTimeout(function(){
					aItemList[i].style.height = listHeight + 'px';
					aItemList[i].style.height = listHeight - 20 + 'px';
				},"1000");
				aItemTitle[i].className += ' current';
				aItemList[i].className = 'item-list animation-in';
				console.log(numHeight);
			}else{
				clearTimeout(timeout);
				aItemTitle[i].className = 'item-list-title';
				aItemList[i].className = 'item-list animation-out';
				aItemList[i].style.height = 30 + 'px';
			}
			
			
		}
	}
	